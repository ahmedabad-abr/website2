AHMEDABAD BUSINESS REVIEW (ABR) - BRAND KIT v1.0 (November 2026)

ABR-Brand-Guidelines.pdf   How to use the logo: versions, clear space, minimum size, colours, typeface, do-nots.

01-Logo/                   Four logo versions, each in Black and White (reversed):
  01-Primary-Stacked       Default logo.
  02-Horizontal            Website header, letterhead, narrow spaces.
  03-Emblem                Stepwell emblem alone.
  04-Short-Form-ABR        Emblem + "ABR" for social and small spaces.
  .svg = website / any size   .pdf = print (vector)   .png = quick use (transparent background)

02-Social/                 1080 x 1080 avatars (Instagram, LinkedIn, X, WhatsApp).
03-Web-Favicon/            favicon.ico, favicon.svg, PNGs 16-512, apple-touch-icon.png.
  HTML:  <link rel="icon" href="/favicon.ico" sizes="any">
         <link rel="icon" href="/favicon.svg" type="image/svg+xml">
         <link rel="apple-touch-icon" href="/apple-touch-icon.png">

Colours: Black #000000 - White #FFFFFF - Paper #F2F0EB (print background only)
Typeface: Inter Display ExtraBold (wordmark, already outlined) - Inter for text (free, SIL Open Font License)
